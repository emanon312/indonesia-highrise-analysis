# Indonesia 12-City High-Rise Buildings - Delivery Guide

## 1. Overview

This package contains the high-rise building analysis (**>=32m, approx. 8 floors and above**) for **12 major Indonesian cities**, totaling **4801 buildings** (per-building caliber).

## 2. Data source & reliability

| Scope | Source | Nature | Buildings |
|-------|--------|--------|-----------|
| Jakarta | Indonesia DPMPTSP official 3D building database (Jakarta Satu) | **Official ground truth** (LOD2 modeling + government validation) | 2556 |
| Other 11 cities | Google Open Buildings V3 footprints + 2.5D height estimation | Machine-learning estimate (conservative lower bound) | 2245 |

- **Jakarta is the official ground-truth benchmark** - height, coordinates and floor area come from government registry.
- **The other 11 cities are ML estimates**; heights are systematically low (a conservative lower bound), so actual heights are only higher. A few landmark towers use CTBUH measured heights (see the "Data Source" column in each Excel).
- DPMPTSP = Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu (Investment and One-Stop Integrated Services Agency), DKI Jakarta Provincial Government. Platform: Jakarta Satu. Data nature: LOD2 3D modeling + government validation (Validasi), scraped 2026-06-22.

## 3. Height tiers

Five tiers by building height (~4m per floor): >=32m (8F) - >=40m (10F) - >=48m (12F) - >=64m (16F) - >=80m (20F).

## 4. Counting calibers

- **Per-building**: each row is one building = **4801** across 12 cities (used by all summary counts).
- **Per building-group**: buildings inside one proximity cluster count as a single complex = 4191 standalone + 271 clusters = **4462**.
- A proximity cluster = several adjacent buildings at the same site (same value in the "Cluster" column). The gap between the two calibers equals the duplicated towers merged inside clusters.

## 5. Deduplication (important)

**A single tower is often counted multiple times**; spatial deduplication was applied to avoid over-counting:
- **Jakarta**: the official registry holds multiple tax/registration records per tower -> exact dedup + same-name proximity + 25m spatial dedup.
- **Other 11 cities**: Google ML may split one tower into several footprint points -> 25m spatial dedup (within 25m radius and <25% height difference merged; adjacent buildings of different heights kept).
- All 12 cities share the same dedup caliber. Hospitals are retained and merged into the commercial high-rise set (not filtered as public facilities).

## 6. File navigation

### Building_Lists_12Cities/
12 Excel files, one per city. Each has 3 sheets: main commercial high-rise list (core data, hospitals included) / removed public facilities / notes.
17 columns per building: building name, name source, data source, coordinates, height, floors, category, district, address, floor area, cluster, etc.
Building names, addresses and sub-districts keep the original Indonesian text (needed for on-site survey and navigation).

### Summary/
- **Indonesia_HighRise_Summary.xlsx** - tier statistics (cumulative thresholds + per-tier detail + notes).

### Report/
- **Indonesia_HighRise_Report.html** - fully English interactive report (overview + map + searchable list + export). Open by double-click; forward directly to external parties.

## 7. Usage notes

- The HTML report **needs internet** to load the map basemap on first open; **building data is embedded (a fixed snapshot) and is never altered by the network**.
- The map library is inlined, so recipients can just double-click to use it.
- Building names and addresses keep the original Indonesian text.

## 8. Key figures

| Metric | Value |
|--------|-------|
| 12-city total (>=32m, per-building) | **4801** |
| Per building-group caliber | **4462** (4191 standalone + 271 clusters) |
| >=80m super-tall | 1039 |
| Jakarta (official ground truth) | 2556 (incl. 90 hospitals) |
| Data snapshot date | 2026-06-22 (Jakarta official scrape) |

---

*Jakarta figures are official deduplicated ground truth; the other 11 cities are Google conservative lower bounds - real counts are only higher. All 12 cities have spatial dedup applied to avoid over-counting a single tower split into multiple points.*
